#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int n;
	scanf("%d", &n);
	int min = 10000000, max = 0, scan;
	for (int i = 0; i < n; i++)
	{
		scanf("%d", &scan);
		if (scan < min)
			min = scan;
		if (scan > max)
			max = scan;
	}
	printf("%d %d", min, max);
	return 0;
}
