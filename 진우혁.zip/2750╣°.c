#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int n, list[1000] = {0};
	scanf("%d", &n);
	for (int k = 0; k < n; k++)
		scanf("%d", &list[k]);
	int i, j, temp, least;
	for (i = 0; i < n - 1; i++)
	{
		least = i;
		for (j = i + 1; j < n; j++)
			if (list[j] < list[least])
				least = j;
		temp = list[i];
		list[i] = list[least];
		list[least] = temp;
	}
	for (i = 0; i < n; i++)
		printf("%d\n", list[i]);
	return 0;
}