#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>

void hanoi(int, int, int, int);

int main()
{
	int n;
	scanf("%d", &n);
	int k = pow(2, n) - 1;
	printf("%d", k);
	hanoi(n, 1, 2, 3);
}

void hanoi(int n, int from, int tmp, int to)
{
	if (n <= 1)
	{
		printf("%d %d\n", from, to);
	}
	else
	{
		hanoi(n - 1, from, to, tmp);
		printf("%d %d\n", from, to);
		hanoi(n - 1, tmp, from, to);
	}
}