#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main()
{
	int array[9];
	int max=0;
	for (int i = 0; i < 9; i++)
	{
		scanf("%d", &array[i]);
		if (array[max] < array[i])
			max = i;
	}
	printf("%d\n%d", array[max], max);
	return 0;
}